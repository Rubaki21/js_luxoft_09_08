
// export default {
const DATA = {
	employees: [
		{
			id: 1,
			name: "Пафнутий",
			surname: "Пафнутьев",
			department: "IT",
			dateOfBirth: "2000-01-01"
		},
		{
			id: 133,
			name: "Иван",
			surname: "Иванов",
			department: "HR",
			managerRef: 135,
		},
		{
			id: 134,
			name: "Анна",
			surname: "Петрова",
			department: "HR"
		},
		{
			id: 135,
			name: "Николай",
			surname: "Сидоров",
			department: "IT"
		},
		{
			id: 136,
			name: "Иван",
			surname: "Сидоров",
			department: "IT"
		},
		{
			id: 137,
			name: "Петр",
			surname: "Сидоров",
			department: "IT"
		}
	]
};
const employeeMap = {};
