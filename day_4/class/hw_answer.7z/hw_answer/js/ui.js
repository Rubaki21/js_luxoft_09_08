const PLACEHOLDER = "employeesPlaceholder";
const ERROR_DIV = "addEmployeeFormErrorMessage";
function runUI() {
	showEmployees(DATA.employees);
}


function addEmployeeUI() {
	let errorHTML = "";
    const name = document.getElementById("name").value;
    if (name=="") {
        errorHTML += "- Имя сотрудника должно быть задано<br>";
    }
    const surname = document.getElementById("surname").value;
    if (surname=="") {
        errorHTML += "- Фамилия сотрудника должна быть задана<br>";
    }
    document.getElementById(ERROR_DIV).innerHTML = errorHTML;
    if (errorHTML.length != 0)
        return;

	addEmployee(name, surname);
    showEmployees(DATA.employees);
    document.getElementById("name").value = "";
    document.getElementById("surname").value = "";
}




function clearEmployeesPlaceholder() {
	document.getElementById(PLACEHOLDER).innerHTML = "";
}


/**
 * Данная функция ответственна за отрисовку списка задач из DATA.tasks.
 * Конечный результат надо поместить в div tasksPlaceholder.
 */
function showEmployees(employees) {
	clearEmployeesPlaceholder();
	const ul = document.createElement("ul");

	for (let employee of employees) {
		const li = document.createElement("li");
		ul.append(li);
        li.innerHTML = employee.name+" "+employee.surname;

	}
	document.getElementById(PLACEHOLDER).append(ul);
}


